/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import interfaces.Notificacao;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class WebNotificacao implements Notificacao{

    @Override
    public void exibir() {
        JOptionPane.showMessageDialog(null, "Notificação Web: Atualização de sistema concluída.", "Notificação Web", JOptionPane.PLAIN_MESSAGE);
    }
    
}
