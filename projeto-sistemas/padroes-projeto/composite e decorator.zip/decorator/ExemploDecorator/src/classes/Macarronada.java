/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author lucas
 */
public class Macarronada extends Massa {
    @Override
    public String getDescricao() {
        return "Macarronada";
    }

    @Override
    public double getPreco() {
        return 17.0;
    }
}