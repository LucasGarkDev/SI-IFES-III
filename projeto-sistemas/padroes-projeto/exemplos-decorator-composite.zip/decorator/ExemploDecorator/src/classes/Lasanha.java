/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author lucas
 */
public class Lasanha extends Massa {
    
    @Override
    public String getDescricao() {
        return "Lasanha";
    }

    @Override
    public double getPreco() {
        return 18.0;
    }
}
