/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller.controll;

import com.dao.ConexaoHibernate;
import java.sql.Connection;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

/**
 *
 * @author lucas
 */
public class GerenciaDominio {
    private final SessionFactory sessionFactory;

    public GerenciaDominio() {
        // Apenas carrega a fábrica de sessões
        this.sessionFactory = ConexaoHibernate.getSessionFactory();
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }
     
}
