/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.domain.Fazenda;
import com.domain.Movimentacao;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 *
 * @author lucas
 */
public class MovimentacaoDAO extends GenericDAO {

    public List<Movimentacao> pesquisarPorFazenda(String nomeFazenda) throws HibernateException {
        return pesquisar(nomeFazenda, 1);
    }

    public List<Movimentacao> pesquisarPorMotivo(String motivo) throws HibernateException {
        return pesquisar(motivo, 2);
    }

    public List<Movimentacao> pesquisarPorData(Date data) throws HibernateException {
        return pesquisarPorDataInterna(data);
    }

    public List<Movimentacao> pesquisarCombinado(String nomeFazenda, String motivo, Date data) throws HibernateException {
        return pesquisarCombinada(nomeFazenda, motivo, data);
    }

    // 🔍 Pesquisa por campo único (tipo 1 = fazenda, 2 = motivo)
    private List<Movimentacao> pesquisar(String valor, int tipo) throws HibernateException {
        Session sessao = null;
        List<Movimentacao> lista = null;

        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery<Movimentacao> consulta = builder.createQuery(Movimentacao.class);
            Root<Movimentacao> root = consulta.from(Movimentacao.class);

            Predicate restricao = null;

            if (tipo == 1) { // Fazenda de origem
                restricao = builder.like(
                    builder.lower(root.get("origem").get("nome")),
                    "%" + valor.toLowerCase() + "%"
                );
            } else if (tipo == 2) { // Motivo
                restricao = builder.like(
                    builder.lower(root.get("motivo")),
                    "%" + valor.toLowerCase() + "%"
                );
            }

            consulta.where(restricao);
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
        } catch (HibernateException e) {
            if (sessao != null) sessao.getTransaction().rollback();
            throw e;
        } finally {
            if (sessao != null) sessao.close();
        }

        return lista;
    }

    // 🔍 Pesquisa por data exata
    private List<Movimentacao> pesquisarPorDataInterna(Date data) throws HibernateException {
        Session sessao = null;
        List<Movimentacao> lista = null;

        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery<Movimentacao> consulta = builder.createQuery(Movimentacao.class);
            Root<Movimentacao> root = consulta.from(Movimentacao.class);

            Predicate restricao = builder.equal(root.get("dataMovimentacao"), data);
            consulta.where(restricao);

            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
        } catch (HibernateException e) {
            if (sessao != null) sessao.getTransaction().rollback();
            throw e;
        } finally {
            if (sessao != null) sessao.close();
        }

        return lista;
    }

    // 🔍 Pesquisa combinada: fazenda + motivo + data
    private List<Movimentacao> pesquisarCombinada(String nomeFazenda, String motivo, Date data) throws HibernateException {
        Session sessao = null;
        List<Movimentacao> lista = null;

        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery<Movimentacao> consulta = builder.createQuery(Movimentacao.class);
            Root<Movimentacao> root = consulta.from(Movimentacao.class);

            List<Predicate> predicados = new ArrayList<>();

            if (nomeFazenda != null && !nomeFazenda.isBlank()) {
                predicados.add(
                    builder.like(
                        builder.lower(root.get("origem").get("nome")),
                        "%" + nomeFazenda.toLowerCase() + "%"
                    )
                );
            }

            if (motivo != null && !motivo.isBlank()) {
                predicados.add(
                    builder.like(
                        builder.lower(root.get("motivo")),
                        "%" + motivo.toLowerCase() + "%"
                    )
                );
            }

            if (data != null) {
                predicados.add(builder.equal(root.get("dataMovimentacao"), data));
            }

            consulta.where(builder.and(predicados.toArray(new Predicate[0])));

            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
        } catch (HibernateException e) {
            if (sessao != null) sessao.getTransaction().rollback();
            throw e;
        } finally {
            if (sessao != null) sessao.close();
        }

        return lista;
    }
    
    public List<Movimentacao> buscarEntradasPorFazenda(Fazenda fazenda) {
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            String hql = "FROM Movimentacao m WHERE m.destino = :fazenda";
            return session.createQuery(hql, Movimentacao.class)
                          .setParameter("fazenda", fazenda)
                          .getResultList();
        }
    }

    public List<Movimentacao> buscarSaidasPorFazenda(Fazenda fazenda) {
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            String hql = "FROM Movimentacao m WHERE m.origem = :fazenda";
            return session.createQuery(hql, Movimentacao.class)
                          .setParameter("fazenda", fazenda)
                          .getResultList();
        }
    }

}
