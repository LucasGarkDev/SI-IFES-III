/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller.controll;

import com.dao.ConexaoHibernate;
import com.dao.MovimentacaoDAO;
import com.domain.Fazenda;
import com.domain.Movimentacao;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;
import org.hibernate.Hibernate;
import org.hibernate.Session;

/**
 *
 * @author lucas
 */
public class GeradorRelatorioFazenda {
    public static void gerarRelatorio(Fazenda fazenda) throws JRException {
        // Compilar relatório principal
        InputStream inputStream = GeradorRelatorioFazenda.class.getResourceAsStream("/relatorios/relatorioFazenda.jrxml");
        JasperReport report = JasperCompileManager.compileReport(inputStream);

        // Compilar sub-relatórios
        JasperReport subBovinos = JasperCompileManager.compileReport(
            GeradorRelatorioFazenda.class.getResourceAsStream("/relatorios/sub_bovinos.jrxml"));
        JasperReport subEntrada = JasperCompileManager.compileReport(
            GeradorRelatorioFazenda.class.getResourceAsStream("/relatorios/sub_entrada.jrxml"));
        JasperReport subSaida = JasperCompileManager.compileReport(
            GeradorRelatorioFazenda.class.getResourceAsStream("/relatorios/sub_saida.jrxml"));

        // Carregar logo
        URL logoURL = GeradorRelatorioFazenda.class.getResource("/imagens/logo.jpeg");

        // Obter dados
        MovimentacaoDAO movimentacaoDAO = new MovimentacaoDAO();
        List<Movimentacao> movimentacoesEntrada = movimentacaoDAO.buscarEntradasPorFazenda(fazenda);
        List<Movimentacao> movimentacoesSaida = movimentacaoDAO.buscarSaidasPorFazenda(fazenda);

        // FILTRO DE VALIDAÇÃO - Não exibir movimentações inválidas
        movimentacoesEntrada = movimentacoesEntrada.stream()
                .filter(m -> !m.getMotivo().equalsIgnoreCase("Abate") && !m.getMotivo().equalsIgnoreCase("Venda"))
                .collect(Collectors.toList());

        movimentacoesSaida = movimentacoesSaida.stream()
                .filter(m -> !m.getMotivo().equalsIgnoreCase("Compra"))
                .collect(Collectors.toList());

        // Parâmetros
        Map<String, Object> parametros = new HashMap<>();
        parametros.put("nomeFazenda", fazenda.getNome());
        parametros.put("localizacaoFazenda", fazenda.getLocalizacao());
        parametros.put("logoPath", logoURL.toString());

        parametros.put("listaBovinos", new JRBeanCollectionDataSource(fazenda.getListaBovinos()));
        parametros.put("movimentacoesEntrada", new JRBeanCollectionDataSource(movimentacoesEntrada));
        parametros.put("movimentacoesSaida", new JRBeanCollectionDataSource(movimentacoesSaida));

        // Passar os sub-relatórios como parâmetros
        parametros.put("sub_bovinos.jasper", subBovinos);
        parametros.put("sub_entrada.jasper", subEntrada);
        parametros.put("sub_saida.jasper", subSaida);

        // Gerar o relatório
        JasperPrint print = JasperFillManager.fillReport(report, parametros, new JREmptyDataSource());
        JasperViewer viewer = new JasperViewer(print, false);
        viewer.setTitle("Relatório da Fazenda");
        viewer.setVisible(true);
    }

}
