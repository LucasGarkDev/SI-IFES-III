/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller.controll;

import com.domain.DadosBovinoParaEdicaoDTO;
import com.dao.BovinoDAO;
import com.dao.ConexaoHibernate;
import com.dao.FazendaDAO;
import com.dao.GenericDAO;
import com.dao.MovimentacaoDAO;
import com.domain.AplicacaoVacina;
import com.domain.AplicacaoVacinaPK;
import com.domain.Bovino;
import com.domain.DadosFazendaParaEdicaoDTO;
import com.domain.Fazenda;
import com.domain.Movimentacao;
import com.domain.Raca;
import com.domain.Vacina;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.criteria.CriteriaQuery;
import javax.swing.JOptionPane;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 *
 * @author lucas
 */
public class GerenciaDominio {
    private final SessionFactory sessionFactory;
    private final GenericDAO genericDao;
    private final BovinoDAO bovinoDAO;
    private final MovimentacaoDAO movimentacaoDAO;
    private final FazendaDAO fazendaDAO;

    public GerenciaDominio() {
        this.sessionFactory = ConexaoHibernate.getSessionFactory();
        this.genericDao = new GenericDAO();
        this.bovinoDAO = new BovinoDAO();
        this.movimentacaoDAO = new MovimentacaoDAO();
        this.fazendaDAO = new FazendaDAO();
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public GenericDAO getGenericDAO() {
        return genericDao;
    }

    public BovinoDAO getBovinoDAO() {
        return bovinoDAO;
    }
    
    public MovimentacaoDAO getMovimentacaoDAO() {
        return movimentacaoDAO;
    }
    
    public FazendaDAO getFazendaDAO() {
        return fazendaDAO;
    }
    
    public long getTotalFazendas() {
        return new FazendaDAO().contarFazendas();
    }

    public double getMediaTamanhoFazendas() {
        return new FazendaDAO().mediaTamanhoFazendas();
    }

    public String getRacaMaisComum() {
        return bovinoDAO.racaMaisComum(); // já existente
    }

    public long getTotalBovinos() {
        return bovinoDAO.contarBovinos(); // já existente
    }

    public long getCapacidadeTotalBovinos() {
        return new FazendaDAO().capacidadeTotalBovinos();
    }
    
    public Map<String, Object> getResumoEstatisticas() {
        Map<String, Object> resumo = new HashMap<>();

        resumo.put("totalFazendas", fazendaDAO.contarFazendas());
        resumo.put("mediaTamanho", fazendaDAO.mediaTamanhoFazendas());
        resumo.put("capacidadeTotal", fazendaDAO.capacidadeTotalBovinos());
        resumo.put("totalBovinos", bovinoDAO.contarBovinos());
        resumo.put("racaMaisComum", bovinoDAO.racaMaisComum());

        return resumo;
    }

    
    public List<Bovino> pesquisarBovinos(Fazenda fazenda, Raca raca, String pesoTexto) {
        List<Bovino> resultados = new ArrayList<>();
        try {
            if (fazenda != null && raca != null) {
                resultados = bovinoDAO.pesquisarPorFazendaERaca(fazenda.getNome(), raca.getNome());
            } else if (fazenda != null) {
                resultados = bovinoDAO.pesquisarPorFazenda(fazenda.getNome());
            } else if (raca != null) {
                resultados = bovinoDAO.pesquisarPorRaca(raca.getNome());
            } else if (pesoTexto != null && !pesoTexto.isEmpty()) {
                double peso = Double.parseDouble(pesoTexto);
                resultados = bovinoDAO.pesquisarPorPesoMaiorQue(peso);
            }
            return resultados;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao pesquisar: " + e.getMessage(), e);
        }
    }

    // Retorna a lista de todas as vacinas
    public List<Vacina> listarVacinas() {
        return genericDao.listar(Vacina.class);
    }

    // Retorna a lista de todas as fazendas
    public List<Fazenda> listarFazendas() {
        return genericDao.listar(Fazenda.class);
    }

    // Retorna a lista de todas as raças
    public List<Raca> listarRacas() {
        return genericDao.listar(Raca.class);
    }
    
    // Lista todos os bovinos machos (pais)
    public List<Bovino> listarBovinosMachos() {
        List<Bovino> todos = genericDao.listar(Bovino.class);
        List<Bovino> machos = new ArrayList<>();
        for (Bovino b : todos) {
            if ("Macho".equalsIgnoreCase(b.getSexo())) {
                machos.add(b);
            }
        }
        return machos;
    }

    // Lista todas as bovinas fêmeas (mães)
    public List<Bovino> listarBovinosFemeas() {
        List<Bovino> todos = genericDao.listar(Bovino.class);
        List<Bovino> femeas = new ArrayList<>();
        for (Bovino b : todos) {
            if ("Fêmea".equalsIgnoreCase(b.getSexo()) || "Femea".equalsIgnoreCase(b.getSexo())) {
                femeas.add(b);
            }
        }
        return femeas;
    }
    
    public void salvarAlteracoesBovino(
        Bovino bovinoEditado,
        String origem,
        Date dataNascimento,
        double peso,
        String status,
        Raca raca,
        Fazenda fazenda,
        String sexo,
        String nomePaiExterno,
        String nomeMaeExterno,
        Integer idPai,
        Integer idMae,
        boolean vacinado,
        Map<Vacina, Date> vacinasSelecionadas
    ) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            Bovino bovino = session.get(Bovino.class, bovinoEditado.getId());
            Hibernate.initialize(bovino.getVacinas());

            bovino.setOrigem(origem);
            bovino.setRaca(raca);
            bovino.setDataNascimento(dataNascimento);
            bovino.setPeso(peso);
            bovino.setStatus(status);
            bovino.setFazenda(fazenda);
            bovino.setSexo(sexo);

            // Linhagem
            if ("Comprado".equalsIgnoreCase(status)) {
                bovino.setNomePaiExterno(nomePaiExterno != null && !nomePaiExterno.isEmpty() ? nomePaiExterno : "Desconhecido");
                bovino.setNomeMaeExterno(nomeMaeExterno != null && !nomeMaeExterno.isEmpty() ? nomeMaeExterno : "Desconhecido");
                bovino.setPai(null);
                bovino.setMae(null);
            } else if ("Nascido na Fazenda".equalsIgnoreCase(status)) {
                if (idPai != null && idMae != null) {
                    Bovino pai = session.get(Bovino.class, idPai);
                    Bovino mae = session.get(Bovino.class, idMae);
                    bovino.setPai(pai);
                    bovino.setMae(mae);
                    bovino.setNomePaiExterno(null);
                    bovino.setNomeMaeExterno(null);
                }
            }

            // Atualização das vacinas
            bovino.getVacinas().clear(); // ativa orphanRemoval
            if (vacinado && vacinasSelecionadas != null) {
                for (Map.Entry<Vacina, Date> entry : vacinasSelecionadas.entrySet()) {
                    Vacina vacina = entry.getKey();
                    Date dataAplicacao = entry.getValue();
                    if (dataAplicacao == null) {
                        throw new IllegalArgumentException("Informe a data para a vacina: " + vacina.getNome());
                    }
                    if (dataAplicacao.before(dataNascimento)) {
                        throw new IllegalArgumentException("A vacina '" + vacina.getNome() + "' não pode ser aplicada antes do nascimento!");
                    }
                    AplicacaoVacina av = new AplicacaoVacina();
                    av.setBovino(bovino);
                    av.setVacina(vacina);
                    av.setDataAplicacao(dataAplicacao);
                    av.setId(new AplicacaoVacinaPK(vacina.getId(), bovino.getId()));

                    bovino.getVacinas().add(av);
                }
            }

            session.merge(bovino);
            tx.commit();
        }
    }

    public DadosBovinoParaEdicaoDTO obterDadosParaEdicaoBovino(int idBovino) {
        try (Session session = sessionFactory.openSession()) {
            Bovino bovino = session.get(Bovino.class, idBovino);
            if (bovino == null) throw new IllegalArgumentException("Bovino não encontrado!");

            DadosBovinoParaEdicaoDTO dto = new DadosBovinoParaEdicaoDTO();
            dto.origem = bovino.getOrigem();
            dto.racaNome = bovino.getRaca() != null ? bovino.getRaca().getNome() : null;
            dto.dataNascimento = bovino.getDataNascimento();
            dto.peso = bovino.getPeso();
            dto.status = bovino.getStatus();
            dto.fazendaNome = bovino.getFazenda() != null ? bovino.getFazenda().getNome() : null;
            dto.sexo = bovino.getSexo();

            Hibernate.initialize(bovino.getVacinas());
            List<AplicacaoVacina> aplicacoes = bovino.getVacinas();
            dto.vacinado = aplicacoes != null && !aplicacoes.isEmpty();
            dto.vacinasSelecionadas = new ArrayList<>();
            dto.vacinasEData = new HashMap<>();
            if (dto.vacinado) {
                for (AplicacaoVacina av : aplicacoes) {
                    dto.vacinasSelecionadas.add(av.getVacina());
                    dto.vacinasEData.put(av.getVacina(), av.getDataAplicacao());
                }
            }
            return dto;
        }
    }

    public void inserirBovino(
        String origem,
        Date dataNascimento,
        double peso,
        String status,
        Raca raca,
        Fazenda fazenda,
        String sexo,
        String nomePaiExterno,
        String nomeMaeExterno,
        Integer idPai,
        Integer idMae,
        boolean vacinado,
        Map<Vacina, Date> vacinasSelecionadas
    ) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            // 1. Cria o bovino
            Bovino novoBovino = new Bovino(origem, raca, dataNascimento, peso, status, fazenda, new ArrayList<>(), sexo);

            // Linhagem
            if ("Comprado".equalsIgnoreCase(status)) {
                novoBovino.setNomePaiExterno(nomePaiExterno != null && !nomePaiExterno.isEmpty() ? nomePaiExterno : "Desconhecido");
                novoBovino.setNomeMaeExterno(nomeMaeExterno != null && !nomeMaeExterno.isEmpty() ? nomeMaeExterno : "Desconhecido");
            } else if ("Nascido na Fazenda".equalsIgnoreCase(status)) {
                if (idPai != null && idMae != null) {
                    Bovino pai = session.get(Bovino.class, idPai);
                    Bovino mae = session.get(Bovino.class, idMae);
                    novoBovino.setPai(pai);
                    novoBovino.setMae(mae);
                }
            }

            // 2. Persiste o bovino (gera ID)
            session.persist(novoBovino);
            session.flush(); // garante que o ID está disponível

            // 3. Atualiza a fazenda (adiciona bovino)
            Fazenda fazendaCompleta = session.get(Fazenda.class, fazenda.getId());
            Hibernate.initialize(fazendaCompleta.getListaBovinos());
            fazendaCompleta.getListaBovinos().add(novoBovino);
            session.merge(fazendaCompleta);

            // 4. Associa vacinas
            if (vacinado && vacinasSelecionadas != null) {
                for (Map.Entry<Vacina, Date> entry : vacinasSelecionadas.entrySet()) {
                    Vacina vacina = entry.getKey();
                    Date dataAplicacao = entry.getValue();

                    if (dataAplicacao == null)
                        throw new IllegalArgumentException("Selecione a data para a vacina: " + vacina.getNome());
                    if (dataAplicacao.before(dataNascimento))
                        throw new IllegalArgumentException("A vacina '" + vacina.getNome() + "' não pode ser aplicada antes do nascimento do bovino!");

                    AplicacaoVacina av = new AplicacaoVacina();
                    av.setVacina(vacina);
                    av.setBovino(novoBovino);
                    av.setDataAplicacao(dataAplicacao);
                    av.setId(new AplicacaoVacinaPK(vacina.getId(), novoBovino.getId()));
                    novoBovino.getVacinas().add(av);
                }
                session.merge(novoBovino); // salva as aplicações
            }

            tx.commit();
        }
    }

    public void excluirBovino(int idBovino) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            Bovino bovino = session.get(Bovino.class, idBovino);
            if (bovino == null)
                throw new IllegalArgumentException("Bovino não encontrado.");

            Hibernate.initialize(bovino.getVacinas());

            // Checa movimentações
            Query<Long> query = session.createQuery(
                "SELECT COUNT(m) FROM Movimentacao m WHERE m.bovino.id = :id", Long.class);
            query.setParameter("id", bovino.getId());
            Long totalMovimentacoes = query.uniqueResult();

            if (totalMovimentacoes != null && totalMovimentacoes > 0) {
                tx.rollback();
                throw new IllegalStateException("Não é possível excluir este bovino, pois ele possui movimentações registradas.");
            }

            // Remove vacinas associadas
            bovino.getVacinas().clear(); // orphanRemoval

            // Remove o bovino
            session.remove(bovino);

            tx.commit();
        }
    }

    public List<Bovino> listarBovinosComVacinas() {
        try (Session session = sessionFactory.openSession()) {
            List<Bovino> bovinos = session.createQuery("FROM Bovino", Bovino.class).list();

            // Inicializa vacinas e as próprias vacinas relacionadas
            for (Bovino bovino : bovinos) {
                Hibernate.initialize(bovino.getVacinas());
                for (AplicacaoVacina av : bovino.getVacinas()) {
                    Hibernate.initialize(av.getVacina());
                }
            }

            return bovinos;
        }
    }

    public boolean capacidadeExcedida(Fazenda fazenda) {
        try (Session session = sessionFactory.openSession()) {
            Fazenda fazendaAtualizada = session.get(Fazenda.class, fazenda.getId());
            Hibernate.initialize(fazendaAtualizada.getListaBovinos());

            int quantidadeAtual = fazendaAtualizada.getListaBovinos().size();
            int capacidadeMaxima = fazenda.getQuantidadeBovinos();

            return quantidadeAtual >= capacidadeMaxima;
        }
    }

    public void inserirFazenda(Fazenda fazenda) {
        genericDao.inserir(fazenda);
    }

    
    public List<Fazenda> listarFazendasComBovinos() {
        try (Session session = sessionFactory.openSession()) {
            CriteriaQuery<Fazenda> query = session.getCriteriaBuilder().createQuery(Fazenda.class);
            query.from(Fazenda.class);
            List<Fazenda> fazendas = session.createQuery(query).getResultList();

            // Inicializa a lista de bovinos de cada fazenda
            for (Fazenda f : fazendas) {
                Hibernate.initialize(f.getListaBovinos());
            }
            return fazendas;
        }
    }

    public DadosFazendaParaEdicaoDTO obterDadosParaEdicaoFazenda(int idFazenda) {
        try (Session session = sessionFactory.openSession()) {
            Fazenda fazenda = session.get(Fazenda.class, idFazenda);
            if (fazenda == null) throw new IllegalArgumentException("Fazenda não encontrada!");

            DadosFazendaParaEdicaoDTO dto = new DadosFazendaParaEdicaoDTO();
            dto.id = fazenda.getId();
            dto.nome = fazenda.getNome();
            dto.cep = fazenda.getCep();
            dto.tamanhoHectares = fazenda.getTamanhoHectares();
            dto.quantidadeBovinos = fazenda.getQuantidadeBovinos();
            dto.observacoes = fazenda.getObservacoes();
            // Inclua outros campos se necessário

            return dto;
        }
    }

    
    public void alterarFazenda(DadosFazendaParaEdicaoDTO dto) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            Fazenda fazenda = session.get(Fazenda.class, dto.id);
            if (fazenda == null) throw new IllegalArgumentException("Fazenda não encontrada!");

            fazenda.setNome(dto.nome);
            fazenda.setCep(dto.cep);
            fazenda.setTamanhoHectares((int) dto.tamanhoHectares);
            fazenda.setObservacoes(dto.observacoes);

            // Correção:
            fazenda.setLocalizacao(dto.localizacao);  // <-- ADICIONAR ESTA LINHA
            fazenda.setQuantidadeBovinos(dto.quantidadeBovinos); // <-- E ESTA

            session.merge(fazenda);
            tx.commit();
        }
    }

    
    
    public void excluirFazenda(int idFazenda) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            Fazenda fazenda = session.get(Fazenda.class, idFazenda);
            if (fazenda == null)
                throw new IllegalArgumentException("Fazenda não encontrada!");

            Hibernate.initialize(fazenda.getListaBovinos());

            // Validação lógica: existe bovino vinculado?
            if (fazenda.getListaBovinos() != null && !fazenda.getListaBovinos().isEmpty()) {
                tx.rollback();
                throw new IllegalStateException("Não é possível excluir esta fazenda pois existem bovinos vinculados a ela.");
            }

            session.remove(fazenda);
            tx.commit();
        } catch (Exception e) {
            // Se for erro de restrição do banco, relança para a View tratar
            throw e;
        }
    }

    public List<Movimentacao> pesquisarMovimentacoes(String fazenda, String motivo, Date data) {
        List<Movimentacao> resultados = new ArrayList<>();
        boolean temFazenda = fazenda != null && !fazenda.trim().isEmpty();
        boolean temMotivo = motivo != null && !motivo.trim().isEmpty();
        boolean temData = data != null;

        if (temFazenda && temMotivo && temData) {
            resultados = movimentacaoDAO.pesquisarCombinado(fazenda, motivo, data);
        } else if (temFazenda && temMotivo) {
            resultados = movimentacaoDAO.pesquisarCombinado(fazenda, motivo, null);
        } else if (temFazenda && temData) {
            resultados = movimentacaoDAO.pesquisarCombinado(fazenda, null, data);
        } else if (temMotivo && temData) {
            resultados = movimentacaoDAO.pesquisarCombinado(null, motivo, data);
        } else if (temFazenda) {
            resultados = movimentacaoDAO.pesquisarPorFazenda(fazenda);
        } else if (temMotivo) {
            resultados = movimentacaoDAO.pesquisarPorMotivo(motivo);
        } else if (temData) {
            resultados = movimentacaoDAO.pesquisarPorData(data);
        } else {
            throw new IllegalArgumentException("Preencha ao menos um campo para buscar.");
        }
        return resultados;
    }

    public List<Bovino> listarBovinos() {
        return genericDao.listar(Bovino.class);
    }
    
    public void inserirMovimentacao(Movimentacao novaMovimentacao) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            // 1. Recupera o bovino ANTES da alteração de fazenda
            Bovino animal = session.get(Bovino.class, novaMovimentacao.getBovino().getId());
            Fazenda origem = animal.getFazenda(); // <-- Origem é a fazenda atual do bovino

            // 2. Recupera o destino corretamente da session
            Fazenda destino = session.get(Fazenda.class, novaMovimentacao.getDestino().getId());

            // 3. Atualiza o bovino para o novo destino
            animal.setFazenda(destino);
            session.merge(animal);

            // 4. Monta e preenche a movimentação
            Movimentacao movimentacaoParaSalvar = new Movimentacao();
            movimentacaoParaSalvar.setBovino(animal);
            movimentacaoParaSalvar.setOrigem(origem);      // <-- CORRIGIDO: seta a origem!
            movimentacaoParaSalvar.setDestino(destino);
            movimentacaoParaSalvar.setTipo(novaMovimentacao.getTipo());
            movimentacaoParaSalvar.setDataMovimentacao(novaMovimentacao.getDataMovimentacao());
            movimentacaoParaSalvar.setMotivo(novaMovimentacao.getMotivo());
            movimentacaoParaSalvar.setObservacoes(novaMovimentacao.getObservacoes());
            // ... outros campos, se houver

            // 5. Persiste a movimentação
            session.persist(movimentacaoParaSalvar);

            tx.commit();
        }
    }



    public List<Movimentacao> listarMovimentacoes() {
        return genericDao.listar(Movimentacao.class);
    }

    public void alterarMovimentacao(Movimentacao movimentacaoEditada) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            // Busca a instância gerenciada da movimentação
            Movimentacao movExistente = session.get(Movimentacao.class, movimentacaoEditada.getId());
            if (movExistente == null)
                throw new IllegalArgumentException("Movimentação não encontrada no banco!");

            // Atualiza os dados
            movExistente.setTipo(movimentacaoEditada.getTipo());
            movExistente.setDataMovimentacao(movimentacaoEditada.getDataMovimentacao());
            movExistente.setMotivo(movimentacaoEditada.getMotivo());
            movExistente.setObservacoes(movimentacaoEditada.getObservacoes());
            movExistente.setDestino(movimentacaoEditada.getDestino());

            // Atualiza a fazenda atual do bovino se o destino mudou
            Bovino bovino = session.get(Bovino.class, movimentacaoEditada.getBovino().getId());
            if (bovino != null) {
                bovino.setFazenda(movimentacaoEditada.getDestino());
                movExistente.setBovino(bovino);
            }

            session.merge(movExistente);
            tx.commit();
        }
    }

    public void excluirMovimentacao(int idMovimentacao) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            Movimentacao movimentacao = session.get(Movimentacao.class, idMovimentacao);
            if (movimentacao == null) {
                tx.rollback();
                throw new IllegalArgumentException("Movimentação não encontrada!");
            }

            session.remove(movimentacao);
            tx.commit();
        }
    }

    
}
