/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import static org.hibernate.criterion.Projections.id;

/**
 *
 * @author lucas
 */
@Entity
@Access(AccessType.FIELD)
public class Bovino implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idBovino;

    private String origem;

    @Temporal(TemporalType.DATE)
    @Column(name = "data_nascimento", nullable = false)
    private Date dataNascimento;

    @Column(name = "peso_atual", nullable = false)
    private double peso;

    private String status;
    
    @Column(nullable = false)
    private String sexo; // "Macho" ou "Fêmea"

    // 🔗 Muitos bovinos para uma raça
    @ManyToOne(optional = false)
    @JoinColumn(name = "raca_id")
    private Raca raca;

    // 🔗 Muitos bovinos para uma fazenda
    @ManyToOne(optional = false)
    @JoinColumn(name = "fazenda_id")
    private Fazenda fazenda;

    // 🔗 Um bovino tem muitas aplicações de vacina
    @OneToMany(
        mappedBy = "bovino",
        cascade = CascadeType.ALL,            // 🧹 Garante que excluir o bovino exclui as vacinas
        orphanRemoval = true,                 // 🧹 Remove da base se for retirado da lista
        fetch = FetchType.EAGER               // Carrega junto
    )
    private List<AplicacaoVacina> vacinas = new ArrayList<>();
    
    // Se for nascido na fazenda, estas referências serão usadas
    @ManyToOne
    @JoinColumn(name = "pai_id", referencedColumnName = "idBovino")
    private Bovino pai;

    @ManyToOne
    @JoinColumn(name = "mae_id", referencedColumnName = "idBovino")
    private Bovino mae;

    // Se for comprado, estas strings serão usadas (opcionalmente)
    private String nomePaiExterno;

    private String nomeMaeExterno;


    public Bovino() {}

    public Bovino(String origem, Raca raca, Date dataNascimento, double peso, String status, Fazenda fazenda, List<AplicacaoVacina> vacinas, String sexo) {
        this.origem = origem;
        this.raca = raca;
        this.dataNascimento = dataNascimento;
        this.peso = peso;
        this.status = status;
        this.fazenda = fazenda;
        this.vacinas = vacinas;
        this.sexo = sexo;
    }

    public Bovino(int idBovino, String origem, Raca raca, Date dataNascimento, double peso, String status, Fazenda fazenda, List<AplicacaoVacina> vacinas, String sexo) {
        this(origem, raca, dataNascimento, peso, status, fazenda, vacinas, sexo);
        this.idBovino = idBovino;
    }


    // Getters e setters
    public int getId() {
        return idBovino;
    }

    public void setId(int idBovino) {
        this.idBovino = idBovino;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public Raca getRaca() {
        return raca;
    }

    public void setRaca(Raca raca) {
        this.raca = raca;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Fazenda getFazenda() {
        return fazenda;
    }

    public void setFazenda(Fazenda fazenda) {
        this.fazenda = fazenda;
    }
    
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Bovino getPai() {
        return pai;
    }

    public void setPai(Bovino pai) {
        this.pai = pai;
    }

    public Bovino getMae() {
        return mae;
    }

    public void setMae(Bovino mae) {
        this.mae = mae;
    }

    
    public String getNomePaiExterno() {
        return nomePaiExterno;
    }

    public void setNomePaiExterno(String nomePaiExterno) {
        this.nomePaiExterno = nomePaiExterno;
    }

    public String getNomeMaeExterno() {
        return nomeMaeExterno;
    }

    public void setNomeMaeExterno(String nomeMaeExterno) {
        this.nomeMaeExterno = nomeMaeExterno;
    }

    

    public List<AplicacaoVacina> getVacinas() {
        return vacinas;
    }

    public void setVacinas(List<AplicacaoVacina> vacinas) {
        this.vacinas = vacinas;
    }

    @Transient
    public String getVacinasFormatadas() {
        if (vacinas == null || vacinas.isEmpty()) {
            return "Nenhuma";
        }

        return vacinas.stream()
                .map(av -> av.getVacina().getNome())
                .collect(Collectors.joining(", "));
    }

    @Override
    public String toString() {
        return idBovino + " - \"" + origem + "\" - " + (raca != null ? raca.getNome() : "Sem raça");
    }
    
    public int getIdBovino() {
        return idBovino;
    }

    public double getPesoAtual() {
        return peso;
    }

}

