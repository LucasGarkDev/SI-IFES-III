/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

/**
 *
 * @author lucas
 */
public class DadosFazendaParaEdicaoDTO {
    public int id;                    // Para saber qual registro está sendo alterado
    public String nome;
    public String cep;
    public double tamanhoHectares;
    public int quantidadeBovinos;
    public String observacoes;
    public String localizacao;
    // Adicione outros campos, se necessário (ex: data de cadastro, status, etc)
}

