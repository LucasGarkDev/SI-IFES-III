/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller.controll;

import com.dao.BovinoDAO;
import com.dao.FazendaDAO;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author lucas
 */
public class EstatisticasService {
    private FazendaDAO fazendaDAO = new FazendaDAO();
    private BovinoDAO bovinoDAO = new BovinoDAO();

    public Map<String, Object> gerarResumo() {
        Map<String, Object> resumo = new HashMap<>();

        resumo.put("totalFazendas", fazendaDAO.contarFazendas());
        resumo.put("mediaTamanho", fazendaDAO.mediaTamanhoFazendas());
        resumo.put("capacidadeTotal", fazendaDAO.capacidadeTotalBovinos());
        resumo.put("totalBovinos", bovinoDAO.contarBovinos());
        resumo.put("racaMaisComum", bovinoDAO.racaMaisComum());

        return resumo;
    }
}
