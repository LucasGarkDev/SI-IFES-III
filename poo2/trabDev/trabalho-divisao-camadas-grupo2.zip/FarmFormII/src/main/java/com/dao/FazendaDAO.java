/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.domain.Fazenda;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;

/**
 *
 * @author lucas
 */
public class FazendaDAO {

    public long contarFazendas() {
        Session session = ConexaoHibernate.getSessionFactory().openSession();
        long count = 0;

        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Long> query = builder.createQuery(Long.class);
            Root<Fazenda> root = query.from(Fazenda.class);

            query.select(builder.count(root));
            count = session.createQuery(query).getSingleResult();
        } finally {
            session.close();
        }

        return count;
    }

    public double mediaTamanhoFazendas() {
        Session session = ConexaoHibernate.getSessionFactory().openSession();
        double media = 0;

        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Double> query = builder.createQuery(Double.class);
            Root<Fazenda> root = query.from(Fazenda.class);

            query.select(builder.avg(root.get("tamanhoHectares")));
            Double resultado = session.createQuery(query).getSingleResult();
            media = resultado != null ? resultado : 0.0;
        } finally {
            session.close();
        }

        return media;
    }

    public long capacidadeTotalBovinos() {
        Session session = ConexaoHibernate.getSessionFactory().openSession();
        long soma = 0;

        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Long> query = builder.createQuery(Long.class);
            Root<Fazenda> root = query.from(Fazenda.class);

            query.select(builder.sumAsLong(root.get("quantidadeBovinos")));
            Long resultado = session.createQuery(query).getSingleResult();
            soma = resultado != null ? resultado : 0;
        } finally {
            session.close();
        }

        return soma;
    }
    
    public List<Fazenda> buscarPorNome(String nome) {
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            String hql = "FROM Fazenda f WHERE LOWER(f.nome) LIKE :nome";
            return session.createQuery(hql, Fazenda.class)
                    .setParameter("nome", "%" + nome.toLowerCase() + "%")
                    .getResultList();
        }
    }

    public List<Fazenda> buscarPorCEP(String cep) {
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            String hql = "FROM Fazenda f WHERE f.cep = :cep";
            return session.createQuery(hql, Fazenda.class)
                    .setParameter("cep", cep)
                    .getResultList();
        }
    }
    
    public Fazenda buscarComBovinosPorId(Integer id) {
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            String hql = "SELECT f FROM Fazenda f LEFT JOIN FETCH f.listaBovinos WHERE f.idFazenda = :id";
            return session.createQuery(hql, Fazenda.class)
                          .setParameter("id", id)
                          .uniqueResult();
        }
    }


}

