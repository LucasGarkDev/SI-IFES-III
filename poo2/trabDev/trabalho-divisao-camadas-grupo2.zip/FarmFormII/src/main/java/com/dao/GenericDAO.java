/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import java.util.List;
import javax.persistence.criteria.CriteriaQuery;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author lucas
 */
public class GenericDAO {
    public <T> void inserir(T obj) throws HibernateException {
        executarTransacao(session -> session.save(obj));
    }

    public <T> void alterar(T obj) throws HibernateException {
        executarTransacao(session -> session.merge(obj));
    }

    public <T> void excluir(T obj) throws HibernateException {
        executarTransacao(session -> session.delete(obj));
    }

    
    public <T> List<T> listar(Class<T> clazz) throws HibernateException {
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            CriteriaQuery<T> query = session.getCriteriaBuilder().createQuery(clazz);
            query.from(clazz);
            return session.createQuery(query).getResultList();
        }
    }

    public <T> T buscarPorId(Class<T> clazz, int id) throws HibernateException {
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            return session.get(clazz, id);
        }
    }

    // Método auxiliar para evitar duplicação de código em transações
    private void executarTransacao(DAOOperacao operacao) throws HibernateException {
        Transaction tx = null;
        try (Session session = ConexaoHibernate.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            operacao.executar(session);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new HibernateException(e);
        }
    }

    // Interface funcional para passar operações como lambda
    @FunctionalInterface
    private interface DAOOperacao {
        void executar(Session session);
    }
}

