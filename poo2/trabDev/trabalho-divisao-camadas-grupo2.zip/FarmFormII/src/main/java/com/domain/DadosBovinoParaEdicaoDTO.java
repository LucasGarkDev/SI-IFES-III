/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import com.domain.Vacina;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 *
 * @author lucas
 */
public class DadosBovinoParaEdicaoDTO {
    public String origem;
    public String racaNome;
    public Date dataNascimento;
    public double peso;
    public String status;
    public String fazendaNome;
    public String sexo;
    public boolean vacinado;
    public List<Vacina> vacinasSelecionadas;
    public Map<Vacina, Date> vacinasEData;
}
