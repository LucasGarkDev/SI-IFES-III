/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;


/**
 *
 * @author lucas
 */

import com.domain.Bovino;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.Hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;


public class BovinoDAO extends GenericDAO {

    public List<Bovino> pesquisarPorFazenda(String nomeFazenda) throws HibernateException {
        return pesquisar(nomeFazenda, 1);
    }

    public List<Bovino> pesquisarPorRaca(String nomeRaca) throws HibernateException {
        return pesquisar(nomeRaca, 2);
    }

    public List<Bovino> pesquisarPorPesoMaiorQue(double peso) throws HibernateException {
        return pesquisarPeso(peso, 1);
    }

    public List<Bovino> pesquisarPorPesoMenorQue(double peso) throws HibernateException {
        return pesquisarPeso(peso, 2);
    }

    public List<Bovino> pesquisarPorPesoEntre(double min, double max) throws HibernateException {
        return pesquisarPesoEntre(min, max);
    }

    public List<Bovino> pesquisarPorFazendaERaca(String nomeFazenda, String nomeRaca) throws HibernateException {
        return pesquisarCombinado(nomeFazenda, nomeRaca);
    }
    
    

    // 🔍 Pesquisa única por campo (tipo = 1 = fazenda, 2 = raça)
    private List<Bovino> pesquisar(String valor, int tipo) throws HibernateException {
        Session sessao = null;
        List<Bovino> lista = null;

        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery<Bovino> consulta = builder.createQuery(Bovino.class);
            Root<Bovino> root = consulta.from(Bovino.class);

            Predicate restricao = null;

            if (tipo == 1) { // Fazenda
                restricao = builder.like(builder.lower(root.get("fazenda").get("nome")), "%" + valor.toLowerCase() + "%");
            } else if (tipo == 2) { // Raça
                restricao = builder.like(builder.lower(root.get("raca").get("nome")), "%" + valor.toLowerCase() + "%");
            }

            consulta.where(restricao);
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
        } catch (HibernateException e) {
            if (sessao != null) sessao.getTransaction().rollback();
            throw e;
        } finally {
            if (sessao != null) sessao.close();
        }

        return lista;
    }

    // 🔍 Pesquisa por peso (tipo = 1 = maior que, 2 = menor que)
    private List<Bovino> pesquisarPeso(double peso, int tipo) throws HibernateException {
        Session sessao = null;
        List<Bovino> lista = null;

        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery<Bovino> consulta = builder.createQuery(Bovino.class);
            Root<Bovino> root = consulta.from(Bovino.class);

            Predicate restricao = tipo == 1
                ? builder.greaterThanOrEqualTo(root.get("peso"), peso)
                : builder.lessThanOrEqualTo(root.get("peso"), peso);

            consulta.where(restricao);
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
        } catch (HibernateException e) {
            if (sessao != null) sessao.getTransaction().rollback();
            throw e;
        } finally {
            if (sessao != null) sessao.close();
        }

        return lista;
    }

    // 🔍 Peso entre dois valores
    private List<Bovino> pesquisarPesoEntre(double min, double max) throws HibernateException {
        Session sessao = null;
        List<Bovino> lista = null;

        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery<Bovino> consulta = builder.createQuery(Bovino.class);
            Root<Bovino> root = consulta.from(Bovino.class);

            Predicate restricao = builder.between(root.get("peso"), min, max);

            consulta.where(restricao);
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
        } catch (HibernateException e) {
            if (sessao != null) sessao.getTransaction().rollback();
            throw e;
        } finally {
            if (sessao != null) sessao.close();
        }

        return lista;
    }

    // 🔍 Pesquisa combinada: Fazenda + Raça
    private List<Bovino> pesquisarCombinado(String nomeFazenda, String nomeRaca) throws HibernateException {
        Session sessao = null;
        List<Bovino> lista = null;

        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery<Bovino> consulta = builder.createQuery(Bovino.class);
            Root<Bovino> root = consulta.from(Bovino.class);

            Predicate byFazenda = builder.like(builder.lower(root.get("fazenda").get("nome")), "%" + nomeFazenda.toLowerCase() + "%");
            Predicate byRaca = builder.like(builder.lower(root.get("raca").get("nome")), "%" + nomeRaca.toLowerCase() + "%");

            consulta.where(builder.and(byFazenda, byRaca));
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
        } catch (HibernateException e) {
            if (sessao != null) sessao.getTransaction().rollback();
            throw e;
        } finally {
            if (sessao != null) sessao.close();
        }

        return lista;
    }
    
    public long contarBovinos() {
        Session session = ConexaoHibernate.getSessionFactory().openSession();
        long count = 0;

        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Long> query = builder.createQuery(Long.class);
            Root<Bovino> root = query.from(Bovino.class);

            query.select(builder.count(root));
            count = session.createQuery(query).getSingleResult();
        } finally {
            session.close();
        }

        return count;
    }


    public String racaMaisComum() {
        Session session = ConexaoHibernate.getSessionFactory().openSession();
        String raca = "Nenhuma";

        try {
            session.beginTransaction();

            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
            Root<Bovino> root = query.from(Bovino.class);

            Path<String> nomeRaca = root.get("raca").get("nome");

            query.multiselect(nomeRaca, builder.count(root));
            query.groupBy(nomeRaca);
            query.orderBy(builder.desc(builder.count(root)));

            List<Object[]> result = session.createQuery(query).setMaxResults(1).getResultList();

            if (!result.isEmpty()) {
                raca = (String) result.get(0)[0];
            }

            session.getTransaction().commit();
        } catch (HibernateException e) {
            session.getTransaction().rollback();
            throw e;
        } finally {
            session.close();
        }

        return raca;
    }

    
    


}
