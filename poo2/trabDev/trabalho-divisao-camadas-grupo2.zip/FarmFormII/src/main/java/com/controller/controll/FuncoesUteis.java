/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller.controll;

import com.domain.Endereco;
import java.awt.Window;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import org.json.JSONObject;

/**
 *
 * @author lucas
 */
public class FuncoesUteis {
    
    /**
     * Limpa campos de texto, spinner, checkbox, textarea, formatted text e lista.
     * @param txtNome JTextField - Campo de texto do nome
     * @param txtPreco JTextField - Campo de texto do preço
     * @param spnQuantidade JSpinner - Componente numérico de quantidade
     * @param listCategorias JList<String> - Lista de categorias selecionáveis
     * @param txtObservacao JTextArea - Área de texto para observações
     * @param txtFormatado JFormattedTextField - Campo de texto formatado
     * @param chkOpcao JCheckBox - Checkbox de opção
     * @param rdbGrupo ButtonGroup - Grupo de botões de rádio
     */
    public static void limparCampos(JTextField txtNome, JTextField txtPreco, 
                                JSpinner spnQuantidade, JList<String> listCategorias, 
                                JTextField txtObservacao, JFormattedTextField txtFormatado, 
                                JCheckBox chkOpcao, ButtonGroup rdbGrupo) {
        // Limpa campos de texto apenas se não forem nulos
        if (txtNome != null) txtNome.setText("");
        if (txtPreco != null) txtPreco.setText("");

        // Reseta JSpinner apenas se não for nulo
        if (spnQuantidade != null) spnQuantidade.setValue(0);

        // Remove seleções da JList apenas se não for nula
        if (listCategorias != null) listCategorias.clearSelection();

        // Limpa JTextArea apenas se não for nula
        if (txtObservacao != null) txtObservacao.setText("");

        // Limpa JFormattedTextField apenas se não for nulo
        if (txtFormatado != null) txtFormatado.setText("");

        // Desmarca JCheckBox apenas se não for nulo
        if (chkOpcao != null) chkOpcao.setSelected(false);

        // Desmarca os RadioButtons dentro do grupo apenas se não for nulo
        if (rdbGrupo != null) rdbGrupo.clearSelection();
    }
    
    
    public static Endereco consultarCEP(String cep) throws MalformedURLException, IOException  {

        Endereco ender = null;
        
        // Definir a URL do serviço ViaCEP
        URL url = new URL("https://viacep.com.br/ws/" + cep + "/json/");

        // Definir a URL do serviço GOV.BR
        //URL url = new URL("https://h-apigateway.conectagov.estaleiro.serpro.gov.br/api-cep/v1/consulta/cep/" + cep);

        // Abrir conexão HTTP
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        // Ler a resposta
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        // Converter a resposta JSON em um objeto JSONObject
        JSONObject jsonObject = new JSONObject(response.toString());

        // Exibir as informações do endereço
        if (!jsonObject.has("erro")) {                            

            ender = new Endereco();
            ender.setLogradouro(jsonObject.getString("logradouro"));
            ender.setBairro(jsonObject.getString("bairro") );
            ender.setCidade(jsonObject.getString("localidade") );
            ender.setUf(jsonObject.getString("uf") );

        } else {
            System.out.println("CEP não encontrado.");
               
        }

        // Fechar conexão
        connection.disconnect();
        return ender;

    }    


    // 🔹 Métodos para obter valores de componentes Swing 🔹

    /**
     * Obtém o texto de um JTextField.
     * @param txtField JTextField - Campo de texto
     * @return String - Valor do campo de texto
     */
    public static String getTexto(JTextField txtField) {
        return txtField.getText();
    }

    /**
     * Define um novo valor para um JTextField.
     * @param txtField JTextField - Campo de texto
     * @param valor String - Novo valor a ser definido
     */
    public static void setTexto(JTextField txtField, String valor) {
        txtField.setText(valor);
    }

    /**
     * Obtém o valor numérico de um JSpinner.
     * @param spinner JSpinner - Componente numérico
     * @return int - Valor atual do spinner
     */
    public static int getValorSpinner(JSpinner spinner) {
        return (int) spinner.getValue();
    }

    /**
     * Define um novo valor para um JSpinner.
     * @param spinner JSpinner - Componente numérico
     * @param valor int - Novo valor a ser definido
     */
    public static void setValorSpinner(JSpinner spinner, int valor) {
        spinner.setValue(valor);
    }

    /**
     * Obtém o texto de um JTextArea.
     * @param txtArea JTextArea - Área de texto
     * @return String - Conteúdo do JTextArea
     */
    public static String getTextoArea(JTextArea txtArea) {
        return txtArea.getText();
    }

    /**
     * Define um novo valor para um JTextArea.
     * @param txtArea JTextArea - Área de texto
     * @param valor String - Novo valor a ser definido
     */
    public static void setTextoArea(JTextArea txtArea, String valor) {
        txtArea.setText(valor);
    }

    /**
     * Obtém o valor de um JFormattedTextField.
     * @param txtFormatado JFormattedTextField - Campo de texto formatado
     * @return String - Texto formatado
     */
    public static String getTextoFormatado(JFormattedTextField txtFormatado) {
        return txtFormatado.getText();
    }

    /**
     * Define um novo valor para um JFormattedTextField.
     * @param txtFormatado JFormattedTextField - Campo de texto formatado
     * @param valor String - Novo valor a ser definido
     */
    public static void setTextoFormatado(JFormattedTextField txtFormatado, String valor) {
        txtFormatado.setText(valor);
    }

    /**
     * Obtém o estado de um JCheckBox.
     * @param chkBox JCheckBox - Checkbox
     * @return boolean - True se estiver marcado, False se não
     */
    public static boolean isCheckBoxSelecionado(JCheckBox chkBox) {
        return chkBox.isSelected();
    }

    /**
     * Define o estado de um JCheckBox.
     * @param chkBox JCheckBox - Checkbox
     * @param selecionado boolean - True para marcar, False para desmarcar
     */
    public static void setCheckBoxSelecionado(JCheckBox chkBox, boolean selecionado) {
        chkBox.setSelected(selecionado);
    }

    /**
     * Obtém o valor selecionado de um JList.
     * @param list JList<String> - Lista de seleção
     * @return List<String> - Lista com os itens selecionados
     */
    public static List<String> getItensSelecionadosLista(JList<String> list) {
        return list.getSelectedValuesList();
    }

    /**
     * Define os itens selecionados de um JList.
     * @param list JList<String> - Lista de seleção
     * @param indices int[] - Índices dos itens a serem selecionados
     */
    public static void setItensSelecionadosLista(JList<String> list, int[] indices) {
        list.setSelectedIndices(indices);
    }

    /**
     * Obtém o RadioButton selecionado dentro de um ButtonGroup.
     * @param grupo ButtonGroup - Grupo de botões de rádio
     * @return String - Texto do botão selecionado ou null se nenhum estiver selecionado
     */
    public static String getRadioButtonSelecionado(ButtonGroup grupo) {
        for (var buttons = grupo.getElements(); buttons.hasMoreElements(); ) {
            AbstractButton button = buttons.nextElement();
            if (button.isSelected()) {
                return button.getText();
            }
        }
        return null; // Retorna null se nenhum estiver selecionado
    }


    /**
     * Define um RadioButton como selecionado dentro de um ButtonGroup.
     * @param grupo ButtonGroup - Grupo de botões de rádio
     * @param valor String - Texto do RadioButton que deseja selecionar
     */
    public static void setRadioButtonSelecionado(ButtonGroup grupo, String valor) {
        for (var buttons = grupo.getElements(); buttons.hasMoreElements(); ) {
            AbstractButton button = buttons.nextElement();
            if (button.getText().equalsIgnoreCase(valor)) {
                button.setSelected(true);
                break; // Para a busca ao encontrar o botão correto
            }
        }
    }
    
   /**
     * Transfere os dados da linha selecionada da JTable para os campos da interface.
     * @param tabela JTable - Tabela onde a linha é selecionada.
     * @param camposEntrada JComponent[] - Array de componentes onde os dados serão inseridos.
     */
    public static void preencherCamposComLinhaSelecionada(JTable tabela, JComponent[] camposEntrada) {
        int linhaSelecionada = tabela.getSelectedRow();

        if (linhaSelecionada >= 0) {
            for (int i = 0; i < camposEntrada.length; i++) {
                Object valorCelula = tabela.getValueAt(linhaSelecionada, i);

                if (valorCelula != null) {
                    if (camposEntrada[i] instanceof JTextField) {
                        ((JTextField) camposEntrada[i]).setText(valorCelula.toString());
                    } else if (camposEntrada[i] instanceof JSpinner) {
                        ((JSpinner) camposEntrada[i]).setValue(Integer.parseInt(valorCelula.toString()));
                    } else if (camposEntrada[i] instanceof JCheckBox) {
                        ((JCheckBox) camposEntrada[i]).setSelected(Boolean.parseBoolean(valorCelula.toString()));
                    } else if (camposEntrada[i] instanceof JList) {
                        JList<String> lista = (JList<String>) camposEntrada[i];

                        // Se for uma lista, transformamos a String em uma lista de elementos
                        if (valorCelula instanceof List) {
                            List<String> valoresLista = (List<String>) valorCelula;
                            lista.setSelectedIndices(getIndicesSelecionados(lista, valoresLista));
                        } else {
                            String[] valoresLista = valorCelula.toString().split(", ");
                            lista.setSelectedIndices(getIndicesSelecionados(lista, Arrays.asList(valoresLista)));
                        }
                    } else if (camposEntrada[i] instanceof JTextField ){
                        ((JTextField) camposEntrada[i]).setText(valorCelula.toString());
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecione uma linha da tabela!", "Atenção", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Método auxiliar para encontrar os índices dos itens que devem ser selecionados na JList.
     * @param lista JList<String> - Lista gráfica da interface.
     * @param valoresSelecionados List<String> - Lista de valores que devem ser selecionados.
     * @return int[] - Índices dos valores que serão selecionados na JList.
     */
    private static int[] getIndicesSelecionados(JList<String> lista, List<String> valoresSelecionados) {
        ListModel<String> model = lista.getModel();
        int[] indices = new int[valoresSelecionados.size()];
        int count = 0;

        for (int i = 0; i < model.getSize(); i++) {
            if (valoresSelecionados.contains(model.getElementAt(i))) {
                indices[count++] = i;
            }
        }

        return Arrays.copyOf(indices, count); // Retorna apenas os índices encontrados
    }

    
    /**
     * Adiciona os valores dos componentes selecionados na tabela.
     * @param tabela JTable - A tabela onde a nova linha será adicionada.
     * @param componentes JComponent[] - Array de componentes (JTextField, JSpinner, etc.).
     */
    public static void adicionarLinhaNaTabela(JTable tabela, JComponent[] componentes, ButtonGroup grupo) {
        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
        List<Object> valoresLinha = new ArrayList<>();

        for (JComponent componente : componentes) {
            if (componente instanceof JTextField) {
                valoresLinha.add(((JTextField) componente).getText());
            } else if (componente instanceof JFormattedTextField) {
                valoresLinha.add(((JFormattedTextField) componente).getText());
            } else if (componente instanceof JTextArea) {
                valoresLinha.add(((JTextArea) componente).getText());
            } else if (componente instanceof JSpinner) {
                valoresLinha.add(((JSpinner) componente).getValue());
            } else if (componente instanceof JCheckBox) {
                valoresLinha.add(((JCheckBox) componente).isSelected());
            } else if (componente instanceof JList) {
                JList<String> lista = (JList<String>) componente;
                List<String> selecionados = lista.getSelectedValuesList();
                valoresLinha.add(String.join(", ", selecionados)); // Converte lista para String
            } else if ("txtNomeArquivo".equals(componente.getName())){
                valoresLinha.add(((JTextField) componente).getText());
            }
        }

        // Adicionamos separadamente o valor do ButtonGroup, se existir
        if (grupo != null) {
            valoresLinha.add(getRadioButtonSelecionado(grupo));
        }

        // Adiciona a linha à tabela
        modelo.addRow(valoresLinha.toArray());
    }

    /**
     * Obtém o texto do RadioButton selecionado dentro de um ButtonGroup.
     * @param grupo ButtonGroup - Grupo de botões de rádio.
     * @return String - Texto do botão selecionado ou null se nenhum estiver selecionado.
     */
    
    
    /**
     * Abre um JFileChooser para selecionar um arquivo e exibe o caminho no JTextField.
     * Inicia sempre na pasta Downloads do sistema.
     * 
     * @param parent JFrame ou JDialog - Janela pai (pode ser "this" dentro da interface gráfica).
     * @param textField JTextField - Campo onde o caminho do arquivo será armazenado.
     * @param descricaoFiltro String - Descrição do filtro (ex: "Imagens PNG e JPG").
     * @param extensoes String... - Extensões permitidas (ex: "png", "jpg", "pdf").
     */
    public static void selecionarArquivo(Window parent, JTextField textField, String descricaoFiltro, String... extensoes) {
        JFileChooser fileChooser = new JFileChooser();

        // Obtém a pasta Downloads do usuário
        String home = System.getProperty("user.home"); 
        File downloads = new File(home, "Downloads");
        fileChooser.setCurrentDirectory(downloads); // Define Downloads como diretório inicial

        // Se houver extensões especificadas, define um filtro
        if (extensoes != null && extensoes.length > 0) {
            FileNameExtensionFilter filtro = new FileNameExtensionFilter(descricaoFiltro, extensoes);
            fileChooser.setFileFilter(filtro);
        }

        // Abre o JFileChooser e verifica se o usuário selecionou um arquivo
        int resultado = fileChooser.showOpenDialog(parent);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File arquivoSelecionado = fileChooser.getSelectedFile();
            textField.setText(arquivoSelecionado.getAbsolutePath()); // Armazena o caminho no JTextField
        } else {
            JOptionPane.showMessageDialog(parent, "Nenhum arquivo foi selecionado.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
}
