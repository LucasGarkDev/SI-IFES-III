/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class ConectionPostgresql {
     private static Connection conexao = null;

    // Dados da conexão (SUBSTITUA PELOS SEUS DADOS)
    private static final String SERVIDOR = "localhost";  // Ou o IP do seu servidor
    private static final String BANCO = "farmformLL";  // Nome do banco de dados
    private static final String USUARIO = "postgres"; // Seu usuário do PostgreSQL
    private static final String SENHA = "123";  // Sua senha do PostgreSQL
    private static final String URL = "jdbc:postgresql://" + SERVIDOR + "/" + BANCO;

    // Construtor privado para evitar instanciação externa
    private ConectionPostgresql() {}

    // Método para obter a conexão única (Singleton)
    public static Connection obterConexao() {
        if (conexao == null) {
            try {
                Class.forName("org.postgresql.Driver"); // Carregar o driver JDBC do PostgreSQL
                conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
                System.out.println("Conexão com o banco de dados estabelecida!");
            } catch (ClassNotFoundException e) {
                JOptionPane.showMessageDialog(null, "Driver JDBC não encontrado!", "Erro", JOptionPane.ERROR_MESSAGE);
                System.exit(1); // Fecha a aplicação
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                System.exit(1); // Fecha a aplicação
            }
        }
        return conexao;
    }

    // Método para fechar a conexão (opcional, caso queira fechar manualmente)
    public static void fecharConexao() {
        if (conexao != null) {
            try {
                conexao.close();
                conexao = null;
                System.out.println("Conexão com o banco de dados fechada.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao fechar conexão!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
