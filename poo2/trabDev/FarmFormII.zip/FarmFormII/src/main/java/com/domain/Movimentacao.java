/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import java.util.Date;

/**
 *
 * @author lucas
 */
public class Movimentacao {
    private int id;
    private String apelidoAnimal;
    private String tipo;
    private Date dataMovimentacao;
    private String destino;
    private String motivo;
    private String observacoes;

    // Construtor completo
    public Movimentacao(int id, String apelidoAnimal, String tipo, Date dataMovimentacao, String destino, String motivo, String observacoes) {
        this.id = id;
        this.apelidoAnimal = apelidoAnimal;
        this.tipo = tipo;
        this.dataMovimentacao = dataMovimentacao;
        this.destino = destino;
        this.motivo = motivo;
        this.observacoes = observacoes;
    }

    // Construtor sem observações
    public Movimentacao(int id, String apelidoAnimal, String tipo, Date dataMovimentacao, String destino, String motivo) {
        this(id, apelidoAnimal, tipo, dataMovimentacao, destino, motivo, "");
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getApelidoAnimal() {
        return apelidoAnimal;
    }

    public void setApelidoAnimal(String apelidoAnimal) {
        this.apelidoAnimal = apelidoAnimal;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Date getDataMovimentacao() {
        return dataMovimentacao;
    }

    public void setDataMovimentacao(Date dataMovimentacao) {
        this.dataMovimentacao = dataMovimentacao;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }
}
