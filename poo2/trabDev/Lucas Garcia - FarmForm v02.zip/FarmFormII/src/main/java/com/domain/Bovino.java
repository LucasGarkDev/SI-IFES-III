/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import java.util.Date;
import java.util.List;

/**
 *
 * @author lucas
 */
public class Bovino {
    
    private int id;
    private String origem;
    private String raca;
    private Date dataNascimento;
    private double peso;
    private String status;
    private String fazenda;
    private List<String> vacinas;
    

    public Bovino(int id, String origem, String raca, Date dataNascimento, double peso, String status, String fazenda, List<String> vacinas) {
        this.id = id;
        this.origem = origem;
        this.raca = raca;
        this.dataNascimento = dataNascimento;
        this.peso = peso;
        this.status = status;
        this.fazenda = fazenda;
        this.vacinas = vacinas;
    }

    public Bovino(int id, String raca, Date dataNascimento, double peso, String status, String fazenda, List<String> vacinas) {
        this.id = id;
        this.raca = raca;
        this.dataNascimento = dataNascimento;
        this.peso = peso;
        this.status = status;
        this.fazenda = fazenda;
        this.vacinas = vacinas;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String Status) {
        this.status = Status;
    }

    public String getFazenda() {
        return fazenda;
    }

    public void setFazenda(String Fazenda) {
        this.fazenda = Fazenda;
    }

    
    
//    public String getNomeFazenda() {
//        return fazenda != null ? fazenda.getNome() : "";
//    }

    public List<String> getVacinas() {
        return vacinas;
    }

    public void setVacinas(List<String> vacinas) {
        this.vacinas = vacinas;
    }

    public String getVacinasFormatadas() {
        return (vacinas == null || vacinas.isEmpty()) ? "Nenhuma" : String.join(", ", vacinas);
    }

}
