/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author lucas
 */
public class ConexaoHibernate {

    private static final SessionFactory sessionFactory;

    static {
        try {
            // Criar o registro com base no hibernate.cfg.xml
            StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                    .configure() // carrega hibernate.cfg.xml
                    .build();

            // Carregar metadados
            Metadata metadata = new MetadataSources(registry)
                    .getMetadataBuilder()
                    .build();

            // DEBUG: Mostra entidades mapeadas
            metadata.getEntityBindings().forEach(e -> {
                System.out.println("Hibernate carregando: " + e.getEntityName());
            });

            // Cria a SessionFactory
            sessionFactory = metadata.buildSessionFactory();

        } catch (Exception ex) {
            System.err.println("Erro ao criar a SessionFactory: " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
