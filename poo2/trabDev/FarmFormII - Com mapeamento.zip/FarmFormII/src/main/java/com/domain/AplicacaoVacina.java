/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lucas
 */
@Entity
@Table(name = "aplicacao_vacina")
public class AplicacaoVacina implements Serializable {

    @EmbeddedId
    private AplicacaoVacinaPK id = new AplicacaoVacinaPK();

    @MapsId("vacinaId")
    @ManyToOne
    @JoinColumn(name = "vacina_id", insertable = false, updatable = false)
    private Vacina vacina;

    @MapsId("bovinoId")
    @ManyToOne
    @JoinColumn(name = "bovino_id", insertable = false, updatable = false)
    private Bovino bovino;

    @Temporal(TemporalType.DATE)
    private Date dataAplicacao;

    private String observacoes;

    public AplicacaoVacina() {}

    public AplicacaoVacina(Vacina vacina, Bovino bovino, Date dataAplicacao, String observacoes) {
        this.id = new AplicacaoVacinaPK(vacina.getId(), bovino.getId());
        this.vacina = vacina;
        this.bovino = bovino;
        this.dataAplicacao = dataAplicacao;
        this.observacoes = observacoes;
    }

    public AplicacaoVacinaPK getId() {
        return id;
    }

    public void setId(AplicacaoVacinaPK id) {
        this.id = id;
    }

    public Vacina getVacina() {
        return vacina;
    }

    public void setVacina(Vacina vacina) {
        this.vacina = vacina;
    }

    public Bovino getBovino() {
        return bovino;
    }

    public void setBovino(Bovino bovino) {
        this.bovino = bovino;
    }

    public Date getDataAplicacao() {
        return dataAplicacao;
    }

    public void setDataAplicacao(Date dataAplicacao) {
        this.dataAplicacao = dataAplicacao;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }
}