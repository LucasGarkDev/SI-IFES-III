/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller.controll;

import com.dao.ConectionPostgresql;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author lucas
 */
public class GerenciaDominio {
    private Connection conexao;

    public GerenciaDominio() {
        // Obtém a conexão ao iniciar
        this.conexao = ConectionPostgresql.obterConexao();
    }

    public Connection getConexao() {
        return conexao;
    }
   
     
}
