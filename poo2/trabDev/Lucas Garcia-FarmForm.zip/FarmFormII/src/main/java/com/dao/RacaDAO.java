/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.domain.Raca;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 *
 * @author lucas
 */
public class RacaDAO {
    
    public List<Raca> listar() throws SQLException{
        
        Statement stmt = ConectionPostgresql.obterConexao().createStatement();
        
        return null;
        
    }
}
