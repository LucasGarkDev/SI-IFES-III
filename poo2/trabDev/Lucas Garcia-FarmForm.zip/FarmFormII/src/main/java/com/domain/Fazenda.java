/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lucas
 */
public class Fazenda {
    private int id;
    private String nome;
    private String localizacao;
    private int tamanhoHectares;
    private int quantidadeBovinos;
    private String observacoes;
    private List<Bovino> listaBovinos;

    // Construtor completo
    public Fazenda(int id, String nome, String localizacao, int tamanhoHectares, int quantidadeBovinos, String observacoes) {
        this.id = id;
        this.nome = nome;
        this.localizacao = localizacao;
        this.tamanhoHectares = tamanhoHectares;
        this.quantidadeBovinos = quantidadeBovinos;
        this.observacoes = observacoes;
        this.listaBovinos = new ArrayList<Bovino>();
    }

    // Construtor sem observações
    public Fazenda(int id, String nome, String localizacao, int tamanhoHectares, int quantidadeBovinos) {
        this(id, nome, localizacao, tamanhoHectares, quantidadeBovinos, "");
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public int getTamanhoHectares() {
        return tamanhoHectares;
    }

    public void setTamanhoHectares(int tamanhoHectares) {
        this.tamanhoHectares = tamanhoHectares;
    }

    public int getQuantidadeBovinos() {
        return quantidadeBovinos;
    }

    public void setQuantidadeBovinos(int quantidadeBovinos) {
        this.quantidadeBovinos = quantidadeBovinos;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public List<Bovino> getListaBovinos() {
        return listaBovinos;
    }

    public void setListaBovinos(List<Bovino> listaBovinos) {
        this.listaBovinos = listaBovinos;
    }
    
    @Override
    public String toString() {
        return nome; 
    }

}
