-- Inserir raças de bovinos
INSERT INTO raca (nome, descricao) VALUES 
('Nelore', 'Raça zebuína muito comum no Brasil, com alta rusticidade.');
INSERT INTO raca (nome, descricao) VALUES 
('Angus', 'Raça de origem escocesa, famosa pela qualidade da carne.');
INSERT INTO raca (nome, descricao) VALUES 
('Guzerá', 'Raça de dupla aptidão, utilizada tanto para carne quanto leite.');
INSERT INTO raca (nome, descricao) VALUES 
('Girolando', 'Raça de leite derivada do cruzamento entre Gir e Holandesa.');
INSERT INTO raca (nome, descricao) VALUES 
('Brahman', 'Raça de origem indiana, muito resistente ao calor.');

-- Inserir vacinas
INSERT INTO vacina (nome, fabricante, descricao) VALUES 
('Ivermectina', 'Zoetis', 'Vermífugo de amplo espectro para bovinos.');
INSERT INTO vacina (nome, fabricante, descricao) VALUES 
('Brucelose', 'MSD Saúde Animal', 'Vacina contra Brucella abortus.');
INSERT INTO vacina (nome, fabricante, descricao) VALUES 
('Febre Aftosa', 'Merck', 'Vacina obrigatória para controle da febre aftosa.');
INSERT INTO vacina (nome, fabricante, descricao) VALUES 
('Carbúnculo Sintomático', 'Vallée', 'Previne doenças clostridiais em bovinos.');
INSERT INTO vacina (nome, fabricante, descricao) VALUES 
('Raiva', 'Ceva Saúde Animal', 'Vacina contra a raiva em bovinos.');