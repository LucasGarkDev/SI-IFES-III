/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "movimentacao")
public class Movimentacao implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idMovimentacao;

    private String tipo;

    @Temporal(TemporalType.DATE)
    @Column(name = "data_movimentacao", nullable = false)
    private Date dataMovimentacao;

    private String motivo;

    private String observacoes;

    // Relacionamento com Bovino
    @ManyToOne(optional = false)
    @JoinColumn(name = "bovino_id")
    private Bovino bovino;

    // Relacionamento com Fazenda (origem)
    @ManyToOne(optional = false)
    @JoinColumn(name = "fazenda_origem_id")
    private Fazenda origem;

    // Relacionamento com Fazenda (destino)
    @ManyToOne(optional = false)
    @JoinColumn(name = "fazenda_destino_id")
    private Fazenda destino;

    public Movimentacao() {}

    public Movimentacao(String tipo, Date dataMovimentacao, String motivo, String observacoes,
                        Bovino bovino, Fazenda origem, Fazenda destino) {
        this.tipo = tipo;
        this.dataMovimentacao = dataMovimentacao;
        this.motivo = motivo;
        this.observacoes = observacoes;
        this.bovino = bovino;
        this.origem = origem;
        this.destino = destino;
    }

    public Movimentacao(int idMovimentacao, String tipo, Date dataMovimentacao, String motivo, String observacoes, Bovino bovino, Fazenda origem, Fazenda destino) {
        this.idMovimentacao = idMovimentacao;
        this.tipo = tipo;
        this.dataMovimentacao = dataMovimentacao;
        this.motivo = motivo;
        this.observacoes = observacoes;
        this.bovino = bovino;
        this.origem = origem;
        this.destino = destino;
    }

    // Getters e Setters
    public int getId() {
        return idMovimentacao;
    }

    public String getTipo() {
        return tipo;
    }

    public Date getDataMovimentacao() {
        return dataMovimentacao;
    }

    public String getMotivo() {
        return motivo;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public Bovino getBovino() {
        return bovino;
    }

    public Fazenda getOrigem() {
        return origem;
    }

    public Fazenda getDestino() {
        return destino;
    }

    public void setId(int id) {
        this.idMovimentacao = id;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setDataMovimentacao(Date dataMovimentacao) {
        this.dataMovimentacao = dataMovimentacao;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public void setBovino(Bovino bovino) {
        this.bovino = bovino;
    }

    public void setOrigem(Fazenda origem) {
        this.origem = origem;
    }

    public void setDestino(Fazenda destino) {
        this.destino = destino;
    }
    
    @Transient
    public String getDescricaoAnimal() {
        return bovino != null ? bovino.getOrigem() : "";
    }

    @Transient
    public String getNomeOrigem() {
        return origem != null ? origem.getNome() : "";
    }

    @Transient
    public String getNomeDestino() {
        return destino != null ? destino.getNome() : "";
    }
}