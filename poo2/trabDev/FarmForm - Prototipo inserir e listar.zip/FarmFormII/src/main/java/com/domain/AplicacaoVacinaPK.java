/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author lucas
 */
@Embeddable
public class AplicacaoVacinaPK implements Serializable {

    @Column(name = "vacina_id")
    private Integer vacinaId;

    @Column(name = "bovino_id")
    private Integer bovinoId;

    public AplicacaoVacinaPK() {}

    public AplicacaoVacinaPK(Integer vacinaId, Integer bovinoId) {
        this.vacinaId = vacinaId;
        this.bovinoId = bovinoId;
    }

    public Integer getVacinaId() {
        return vacinaId;
    }

    public void setVacinaId(Integer vacinaId) {
        this.vacinaId = vacinaId;
    }

    public Integer getBovinoId() {
        return bovinoId;
    }

    public void setBovinoId(Integer bovinoId) {
        this.bovinoId = bovinoId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AplicacaoVacinaPK)) return false;
        AplicacaoVacinaPK that = (AplicacaoVacinaPK) o;
        return Objects.equals(vacinaId, that.vacinaId) &&
               Objects.equals(bovinoId, that.bovinoId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(vacinaId, bovinoId);
    }
}