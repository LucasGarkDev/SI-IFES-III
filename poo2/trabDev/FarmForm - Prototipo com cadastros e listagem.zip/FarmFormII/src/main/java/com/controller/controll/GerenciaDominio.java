/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller.controll;

import com.dao.ConexaoHibernate;
import com.dao.GenericDAO;
import java.sql.Connection;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

/**
 *
 * @author lucas
 */
public class GerenciaDominio {
    private final SessionFactory sessionFactory;
    private final GenericDAO genericDao;

    public GerenciaDominio() {
        this.sessionFactory = ConexaoHibernate.getSessionFactory();
        this.genericDao = new GenericDAO(); // Instanciado uma vez
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public GenericDAO getGenericDAO() {
        return genericDao;
    }
}