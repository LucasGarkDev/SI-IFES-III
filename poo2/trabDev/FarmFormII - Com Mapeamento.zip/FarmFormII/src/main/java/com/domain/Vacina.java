/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.domain;

/**
 *
 * @author lucas
 */
import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "vacina")
public class Vacina implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idVacina;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private String fabricante;

    @Column(length = 500)
    private String descricao;

    // Relacionamento com AplicacaoVacina
    @OneToMany(mappedBy = "vacina")
    private List<AplicacaoVacina> aplicacoes = new ArrayList<>();

    public Vacina() {}

    public Vacina(int id, String nome, String fabricante, String descricao) {
        this.idVacina = id;
        this.nome = nome;
        this.fabricante = fabricante;
        this.descricao = descricao;
    }

    // Getters e Setters

    public int getId() {
        return idVacina;
    }

    public void setId(int id) {
        this.idVacina = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public List<AplicacaoVacina> getAplicacoes() {
        return aplicacoes;
    }

    public void setAplicacoes(List<AplicacaoVacina> aplicacoes) {
        this.aplicacoes = aplicacoes;
    }

    @Override
    public String toString() {
        return nome;
    }
}
